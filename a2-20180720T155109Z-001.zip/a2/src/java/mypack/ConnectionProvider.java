package mypack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

	public  Connection getCon()
	{
	Connection con=null;
		try {
			 Class.forName("com.mysql.jdbc.Driver");
        con=  DriverManager.getConnection("Jdbc:mysql://localhost:3306/crime","root","");
       return con;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
			return con;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return con;
		}
	}

}
